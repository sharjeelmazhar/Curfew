// Curfew, on the login screen only. A phone approval makes the Curfew service write
// /run/curfew-login/select: the account's name and until when (unix seconds). This picks that
// account on the login screen, as a click on it would. The login screen then asks Curfew's PAM
// helper, which lets the account in without its password, once. The file holds no secret.
import GLib from 'gi://GLib';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

const FILE = '/run/curfew-login/select';

export default class CurfewLogin extends Extension {
    enable() {
        this._done = '';
        this._timer = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1000, () => {
            try {
                this._look();
            } catch (e) {
                console.log(`Curfew: ${e}`);
            }
            return GLib.SOURCE_CONTINUE;
        });
    }

    disable() {
        if (this._timer)
            GLib.source_remove(this._timer);
        if (this._later)
            GLib.source_remove(this._later);
        this._timer = this._later = 0;
    }

    _look() {
        let text;
        try {
            text = new TextDecoder().decode(GLib.file_get_contents(FILE)[1]);
        } catch {
            this._done = '';
            return;
        }
        const [name, until] = text.trim().split('\n');
        if (!name || !(Number(until) > Date.now() / 1000) || text === this._done)
            return;
        const dialog = Main.screenShield?._dialog;
        if (!dialog?._userList || !dialog._authPrompt)
            return;
        this._done = text;
        if (dialog._authPrompt.visible) {
            // a password prompt is open (its check for an approval ran before there was one): back to the list, then pick
            dialog.cancel();
            this._later = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 800, () => {
                this._later = 0;
                this._pick(dialog, name);
                return GLib.SOURCE_REMOVE;
            });
            return;
        }
        this._pick(dialog, name);
    }

    _pick(dialog, name) {
        const item = dialog._userList.getItemFromUserName(name);
        if (item) {
            console.log(`Curfew: picking ${name} on the login screen`);
            item.emit('activate');
            return;
        }
        // not on the list (a hidden list, or too many accounts): begin as "Not listed?" would, with the name
        console.log(`Curfew: beginning the login of ${name} (not on the list)`);
        dialog._user = null;
        dialog._setUserListExpanded?.(false);
        dialog._updateCancelButton?.();
        dialog._beginVerification({userName: name});
    }
}
