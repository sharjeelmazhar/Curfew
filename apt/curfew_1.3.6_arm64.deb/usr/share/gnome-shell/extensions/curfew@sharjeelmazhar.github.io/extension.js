// Installed by Curfew. Enabled only in standard (child) accounts, through the dconf profile set up
// by debian/postinst. Airplane mode cuts the Wi-Fi, and with it the parent's phone, so its button
// in the quick settings is hidden here. (Curfew also turns the Wi-Fi back on if it goes off
// another way, and tells the parent.)
// It also takes the screenshots a parent asks for: on GNOME only the shell itself can do that
// without asking on the screen first. Curfew's helper calls it, as this same account.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Shell from 'gi://Shell';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

Gio._promisify(Shell.Screenshot.prototype, 'screenshot');

const SHOT_XML = `<node><interface name="app.curfew.Shell">
    <method name="Screenshot"><arg type="s" direction="in" name="path"/></method>
</interface></node>`;

class Shots {
    // Only a new file in the account's own runtime folder, under the helper's name.
    async ScreenshotAsync([path], invocation) {
        const dir = GLib.get_user_runtime_dir();
        if (GLib.path_get_dirname(path) !== dir || !GLib.path_get_basename(path).startsWith('curfew-shot-')) {
            invocation.return_dbus_error('app.curfew.Shell.Refused', 'not that file');
            return;
        }
        try {
            const stream = Gio.File.new_for_path(path).create(Gio.FileCreateFlags.PRIVATE, null);
            await new Shell.Screenshot().screenshot(false, stream);
            stream.close(null);
            invocation.return_value(null);
        } catch (e) {
            invocation.return_dbus_error('app.curfew.Shell.Failed', String(e));
        }
    }
}

export default class CurfewExtension extends Extension {
    enable() {
        this._shots = Gio.DBusExportedObject.wrapJSObject(SHOT_XML, new Shots());
        this._shots.export(Gio.DBus.session, '/app/curfew/Shell');
        this._shotName = Gio.bus_own_name_on_connection(Gio.DBus.session, 'app.curfew.Shell', Gio.BusNameOwnerFlags.NONE, null, null);
        this._hidden = [];
        // The quick settings build their buttons a moment after the shell starts.
        this._wait = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 250, () => {
            const rfkill = Main.panel.statusArea.quickSettings?._rfkill;
            if (!rfkill)
                return GLib.SOURCE_CONTINUE;
            for (const item of rfkill.quickSettingsItems ?? []) {
                item.visible = false;
                // the button shows itself again whenever the system says airplane mode is there
                const id = item.connect('notify::visible', () => {
                    if (item.visible)
                        item.visible = false;
                });
                this._hidden.push([item, id]);
            }
            this._wait = 0;
            return GLib.SOURCE_REMOVE;
        });
    }

    disable() {
        Gio.bus_unown_name(this._shotName);
        this._shots.unexport();
        this._shots = null;
        if (this._wait)
            GLib.source_remove(this._wait);
        this._wait = 0;
        for (const [item, id] of this._hidden) {
            item.disconnect(id);
            item._manager?.notify('show-airplane-mode');    // shown again if it should be
        }
        this._hidden = [];
    }
}
